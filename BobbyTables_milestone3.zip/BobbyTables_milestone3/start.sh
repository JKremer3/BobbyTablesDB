#!/bin/bash

cd frontend
node ../backend/index.js &
npm start 
